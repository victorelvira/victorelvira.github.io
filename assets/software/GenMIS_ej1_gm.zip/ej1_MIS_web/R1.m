function [EstM,EstM_norm,Zest,ESS_mean] = R1(mu_prop,sig_prop,SIMU,blocks,tipo_target,target_params)

N = length(mu_prop); % number of proposals
N_samples = blocks*N;
index_matrix_sampling = randsrc(SIMU,N_samples,[1:N;ones(1,N)/N]); % indexes of proposals
index_matrix_weights = convert_index_mask(index_matrix_sampling,N);


x_all =  draw_gaussian_uni(index_matrix_sampling,mu_prop,sig_prop);

w = evaluate_target(x_all,tipo_target,target_params)./evaluate_gaussian_uni_bin(x_all,index_matrix_weights,mu_prop,sig_prop);
size(x_all)
sum_w = sum(w,2);

wn = w/N_samples; % normalized target
wn_norm = w./(sum_w*ones(1,N_samples)); % normalized weights

EstM = sum(wn.*x_all,2);
EstM_norm = sum(wn_norm.*x_all,2);

Zest = sum_w/N_samples;

ESS = N*mean(wn_norm,2)./mean(wn_norm.^2,2);
ESS_mean = mean(ESS,1);