function samples_matrix =  draw_gaussian_uni(index_matrix,mu_vec,sig_vec)
% index_matrix is a SIMU x Nsamples matrix with values between 1 and N
% (length of mu_vec and sig_vec). 
samples_matrix = mu_vec(index_matrix) + sig_vec(index_matrix).*randn(size(index_matrix));

 