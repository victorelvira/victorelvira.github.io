clear all
clear all
tic

SIMU=2^15; % number of runs

blocks_vector = 2.^[0 1 2 3 4 5 6 7 8 9 10 11];
SIMU_vector = SIMU./blocks_vector;

%- Proposals
prop_params.mu=[-3 0 3].'; % Colmumn vector
prop_params.sig=[1 1 1].'; % Colmumn vector
N = length(prop_params.mu);

%- Target
target_params.mu = prop_params.mu;
target_params.sig = prop_params.sig;
% target_params.mu = [-3 0 3].';
% target_params.sig = [1 1 1].';
target_modes = length(target_params.mu);

target_mean = mean(target_params.mu);
target_variance = sum((target_params.mu-target_mean).^2 + target_params.sig)/target_modes;
target_Z = 1;

tipo_target = 'gm1';

filename = ['temp_' num2str(randint(1,1,1000000))];
for i=1:length(blocks_vector)    
    i
    blocks = blocks_vector(i);
    SIMU = SIMU_vector(i);
    %% R1
    [EstM_r1 EstM_r1_norm Zest_r1 ESS_r1] = R1(prop_params.mu,prop_params.sig,SIMU,blocks,tipo_target,target_params);
    %% N1
    [EstM_n1 EstM_n1_norm Zest_n1 ESS_n1] = N1(prop_params.mu,prop_params.sig,SIMU,blocks,tipo_target,target_params);
    %% R2
    [EstM_r2 EstM_r2_norm Zest_r2 ESS_r2] = R2(prop_params.mu,prop_params.sig,SIMU,blocks,tipo_target,target_params);
    %% N2
    [EstM_n2 EstM_n2_norm Zest_n2 ESS_n2] = N2(prop_params.mu,prop_params.sig,SIMU,blocks,tipo_target,target_params);
    %% R3
    [EstM_r3 EstM_r3_norm Zest_r3 ESS_r3] = R3(prop_params.mu,prop_params.sig,SIMU,blocks,tipo_target,target_params);
    %% N2
    [EstM_n3 EstM_n3_norm Zest_n3 ESS_n3] = N3(prop_params.mu,prop_params.sig,SIMU,blocks,tipo_target,target_params);
    
    r1.var_EstM(i) = var(EstM_r1);
    n1.var_EstM(i) = var(EstM_n1);
    r2.var_EstM(i) = var(EstM_r2);
    n2.var_EstM(i) = var(EstM_n2);
    r3.var_EstM(i) = var(EstM_r3);
    n3.var_EstM(i) = var(EstM_n3);
    
    
    r1.mse_EstM(i) = mean((EstM_r1 - repmat(target_mean,SIMU,1)).^2);
    n1.mse_EstM(i) = mean((EstM_n1 - repmat(target_mean,SIMU,1)).^2);
    r2.mse_EstM(i) = mean((EstM_r2 - repmat(target_mean,SIMU,1)).^2);
    n2.mse_EstM(i) = mean((EstM_n2 - repmat(target_mean,SIMU,1)).^2);
    r3.mse_EstM(i) = mean((EstM_r3 - repmat(target_mean,SIMU,1)).^2);
    n3.mse_EstM(i) = mean((EstM_n3 - repmat(target_mean,SIMU,1)).^2);
    
    r1.mse_EstM_norm(i) = mean((EstM_r1_norm - repmat(target_mean,SIMU,1)).^2);
    n1.mse_EstM_norm(i) = mean((EstM_n1_norm - repmat(target_mean,SIMU,1)).^2);
    r2.mse_EstM_norm(i) = mean((EstM_r2_norm - repmat(target_mean,SIMU,1)).^2);
    n2.mse_EstM_norm(i) = mean((EstM_n2_norm - repmat(target_mean,SIMU,1)).^2);
    r3.mse_EstM_norm(i) = mean((EstM_r3_norm - repmat(target_mean,SIMU,1)).^2);
    n3.mse_EstM_norm(i) = mean((EstM_n3_norm - repmat(target_mean,SIMU,1)).^2);
    
    r1.mse_Zest(i) = mean((Zest_r1 - repmat(target_Z,SIMU,1)).^2);
    n1.mse_Zest(i) = mean((Zest_n1 - repmat(target_Z,SIMU,1)).^2);
    r2.mse_Zest(i) = mean((Zest_r2 - repmat(target_Z,SIMU,1)).^2);
    n2.mse_Zest(i) = mean((Zest_n2 - repmat(target_Z,SIMU,1)).^2);
    r3.mse_Zest(i) = mean((Zest_r3 - repmat(target_Z,SIMU,1)).^2);
    n3.mse_Zest(i) = mean((Zest_n3 - repmat(target_Z,SIMU,1)).^2);

    r1.Zest_mean(i) = mean(Zest_r1);
    n1.Zest_mean(i) = mean(Zest_n1);
    r2.Zest_mean(i) = mean(Zest_r2);
    n2.Zest_mean(i) = mean(Zest_n2);
    r3.Zest_mean(i) = mean(Zest_r3);
    n3.Zest_mean(i) = mean(Zest_n3);
    
    r1.ESS(i) = ESS_r1/(blocks*N);
    r2.ESS(i) = ESS_r2/(blocks*N);
    r3.ESS(i) = ESS_r3/(blocks*N);
    n1.ESS(i) = ESS_n1/(blocks*N);
    n2.ESS(i) = ESS_n2/(blocks*N);
    n3.ESS(i) = ESS_n3/(blocks*N);

    save(filename,'r1','r2','r3','n1','n2','n3','SIMU','blocks_vector','prop_params','target_params','target_mean','target_variance','target_Z','N')
    i
end

toc

%% Painting

blocks_vector_big = 2.^[0:12];
N_samples_vector_big = N*blocks_vector_big;
N_samples_vector = N*blocks_vector;

line_width = 2;
marker_size = 15;
fin = length(r1.mse_EstM_norm);

fig1 = figure(1);
loglog(N_samples_vector(1:fin),r1.mse_Zest,'yx-','LineWidth',line_width,'MarkerSize',marker_size);hold on
loglog(N_samples_vector(1:fin),n1.mse_Zest,'rs-','LineWidth',line_width,'MarkerSize',marker_size)
loglog(N_samples_vector(1:fin),r2.mse_Zest,'md-','LineWidth',line_width,'MarkerSize',marker_size)
loglog(N_samples_vector(1:fin),n2.mse_Zest,'co-','LineWidth',line_width,'MarkerSize',marker_size)
loglog(N_samples_vector(1:fin),r3.mse_Zest,'g*-','LineWidth',line_width,'MarkerSize',marker_size)
loglog(N_samples_vector(1:fin),n3.mse_Zest,'bv-','LineWidth',line_width,'MarkerSize',marker_size)
title('estimator of Z (R3 and N3 are zero variance without mismatch)')
legend('R1','N1','R2','N2','R3','N3')
xlabel('M')
ylabel('Var')

set(findall(fig1,'-property','FontSize'),'FontSize',20)

hold off
grid on

fig2 = figure(2);
loglog(N_samples_vector_big,target_variance./N_samples_vector_big,'k--','LineWidth',line_width,'MarkerSize',marker_size);hold on
loglog(N_samples_vector(1:fin),r1.mse_EstM,'yx-','LineWidth',line_width,'MarkerSize',marker_size)
loglog(N_samples_vector(1:fin),n1.mse_EstM,'rs-','LineWidth',line_width,'MarkerSize',marker_size)
loglog(N_samples_vector(1:fin),r2.mse_EstM,'md-','LineWidth',line_width,'MarkerSize',marker_size)
loglog(N_samples_vector(1:fin),n2.mse_EstM,'co-','LineWidth',line_width,'MarkerSize',marker_size)
loglog(N_samples_vector(1:fin),r3.mse_EstM,'g*-','LineWidth',line_width,'MarkerSize',marker_size)
loglog(N_samples_vector(1:fin),n3.mse_EstM,'bv-','LineWidth',line_width,'MarkerSize',marker_size)
title('unnormalized estimator of target mean')
legend('Target Sampling','R1','N1','R2','N2','R3','N3')
xlabel('M')
ylabel('MSE')

set(findall(fig2,'-property','FontSize'),'FontSize',20)

hold off
grid on


fig3 = figure(3);
loglog(N_samples_vector_big,target_variance./N_samples_vector_big,'k--','LineWidth',line_width,'MarkerSize',marker_size);hold on
loglog(N_samples_vector(1:fin),r1.mse_EstM_norm,'yx-','LineWidth',line_width,'MarkerSize',marker_size)
loglog(N_samples_vector(1:fin),n1.mse_EstM_norm,'rs-','LineWidth',line_width,'MarkerSize',marker_size)
loglog(N_samples_vector(1:fin),r2.mse_EstM_norm,'md-','LineWidth',line_width,'MarkerSize',marker_size)
loglog(N_samples_vector(1:fin),n2.mse_EstM_norm,'co-','LineWidth',line_width,'MarkerSize',marker_size)
loglog(N_samples_vector(1:fin),r3.mse_EstM_norm,'g*-','LineWidth',line_width,'MarkerSize',marker_size)
loglog(N_samples_vector(1:fin),n3.mse_EstM_norm,'bv-','LineWidth',line_width,'MarkerSize',marker_size)

legend('Target Sampling','R1','N1','R2','N2','R3','N3')
xlabel('M')
ylabel('MSE')

title('self-normalized estimator of target mean')

set(findall(fig3,'-property','FontSize'),'FontSize',20)

hold off
grid on


%% Target and proposals
fig5 = figure(5);
x_grid = [-10:0.01:10].';
y_target = evaluate_target(x_grid,tipo_target,target_params);
plot(x_grid,y_target,'k--','LineWidth',line_width,'MarkerSize',marker_size);hold on

for i=1:N
    y_proposals(:,i) = evaluate_gaussian_uni_bin(x_grid,logical(ones(size(x_grid))),prop_params.mu(i),prop_params.sig(i),1/N*ones(size(x_grid)));
    plot(x_grid,y_proposals(:,i),'b--','LineWidth',line_width,'MarkerSize',marker_size);hold on
end

legend('\pi(x)','q_1(x)','q_2(x)','q_3(x)');
xlabel('x')
set(findall(fig5,'-property','FontSize'),'FontSize',20)
hold off
grid on
