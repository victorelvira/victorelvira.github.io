function prop_eval_matrix =  evaluate_gaussian_uni(x_matrix,index_matrix_weights,mu_vec,sig_vec)
%%% index_matrix: index of the proposals that must be evaluated. 0 value
%%% means the whole mixture.

prop_eval_matrix = -ones(size(index_matrix_weights));
N = length(mu_vec);

single_prop_indices = find(index_matrix_weights ~= 0);
n_sing = length(single_prop_indices);
mixt_prop_indices = find(index_matrix_weights == 0);
n_mixt = length(mixt_prop_indices);

prop_eval_matrix(single_prop_indices) = 1./(sqrt(2*pi*(sig_vec(index_matrix_weights(single_prop_indices))).^2)).*exp(-(x_matrix(single_prop_indices)-mu_vec(index_matrix_weights(single_prop_indices))).^2./(2*(sig_vec(index_matrix_weights(single_prop_indices))).^2));
aux_mixt = 1./(sqrt(2*pi*(ones(n_mixt,1)*sig_vec.').^2)).*exp(-(x_matrix(mixt_prop_indices)*ones(1,N)-ones(n_mixt,1)*mu_vec.').^2./(2*(ones(n_mixt,1)*sig_vec.').^2));
prop_eval_matrix(mixt_prop_indices) = sum(aux_mixt,2)/N; 
 