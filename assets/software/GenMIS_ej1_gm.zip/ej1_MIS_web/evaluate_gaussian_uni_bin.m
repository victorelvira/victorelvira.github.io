function prop_eval_matrix =  evaluate_gaussian_uni_bin(x_matrix,ind_mat,mu_vec,sig_vec,weight_mat)

if nargin<5
    weight_mat = ind_mat+0;
end

[SIMU,N_samples,N] = size(ind_mat);

mu_matrix = repmat(permute(mu_vec,[3 2 1]),[SIMU N_samples 1]);
sig_matrix = repmat(permute(sig_vec,[3 2 1]),[SIMU N_samples 1]);
x_matrix_kron = repmat(x_matrix,[1 1 N]);

prop_eval_matrix_aux = zeros([SIMU N_samples N]);
prop_eval_matrix_aux(ind_mat) = 1./(sqrt(2*pi*(sig_matrix(ind_mat)).^2)).*exp(-(x_matrix_kron(ind_mat)-mu_matrix(ind_mat)).^2./(2*(sig_matrix(ind_mat)).^2));

N_mixands_matrix = sum(ind_mat,3);
prop_eval_matrix = sum(prop_eval_matrix_aux.*weight_mat,3)./N_mixands_matrix; %Nomralized mixtures
