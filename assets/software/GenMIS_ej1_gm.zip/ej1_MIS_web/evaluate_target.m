function target_eval_matrix = evaluate_target(x_matrix,tipo_target,params)

if strcmp(tipo_target,'gm1')
    mu_target = params.mu;
    sig_target = params.sig; 
    index_matrix = zeros(size(x_matrix)); % zeros means evaluating the whole mixture
    target_eval_matrix = evaluate_gaussian_uni(x_matrix,index_matrix,mu_target,sig_target);
end

