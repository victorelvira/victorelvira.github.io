function [EstM,EstM_norm,Zest,ESS_mean,x_all_vec,w]  = N1_multi(prop_params,SIMU,blocks,tipo_target,target_params,x_all_vec)

mu_prop_matrix = prop_params.mu; 
prop_type = prop_params.type;

N = length(mu_prop_matrix); % number of proposals
N_samples = blocks*N;
dim = size(mu_prop_matrix,2);

index_matrix_sampling = kron(ones(SIMU,blocks),1:N);

index_matrix_weights = convert_index_mask(index_matrix_sampling,N);
if ~exist('x_all_vec')
    disp('N1')
    switch prop_type
        case 'g'
            sig_prop_matrix = prop_params.sig;
            x_all_vec =  draw_gaussian_multi(index_matrix_sampling,mu_prop_matrix,sig_prop_matrix);
            prop_eval = evaluate_gaussian_multi_bin(x_all_vec,index_matrix_weights,mu_prop_matrix,sig_prop_matrix);

        case 't'
            nu_vector = prop_params.nu;
            sig_prop_matrix_iso = extrac_diag_iso(prop_params.sig);
            x_all_vec =  draw_tstudent_multi(index_matrix_sampling,mu_prop_matrix,sig_prop_matrix_iso,nu_vector);
            prop_eval = evaluate_tstudent_multi_bin_iso(x_all_vec,index_matrix_weights,mu_prop_matrix,sig_prop_matrix_iso,nu_vector);
    end    
end

target_eval = evaluate_target_multidim(x_all_vec,tipo_target,target_params,SIMU,N_samples);
w = target_eval./prop_eval;

sum_w = sum(w,2);

wn = w/N_samples; % normalized target
wn_norm = w./(sum_w*ones(1,N_samples)); % normalized weights

wn_vec = repmat(reshape(wn.',N_samples*SIMU,1),1,dim);
wn_norm_vec = repmat(reshape(wn_norm.',N_samples*SIMU,1),1,dim);

EstM_vec = wn_vec.*x_all_vec;
EstM_aux = sum(reshape(EstM_vec,N_samples,SIMU,dim),1);
EstM = permute(EstM_aux,[2 3 1]);

EstM_norm_vec = wn_norm_vec.*x_all_vec;
EstM_norm_aux = sum(reshape(EstM_norm_vec,N_samples,SIMU,dim),1);
EstM_norm = permute(EstM_norm_aux,[2 3 1]);

Zest = sum_w/N_samples;

ESS = N*mean(wn_norm,2)./mean(wn_norm.^2,2);
ESS_mean = mean(ESS,1);