function [res_mean res_modes] = compute_mean(tipo_target,target_params)

mu_matrix = target_params.mu;

res_mean = mean(mu_matrix,1);
res_modes = size(mu_matrix,1);