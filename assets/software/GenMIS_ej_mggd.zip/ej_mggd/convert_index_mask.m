function binary_mask_bin = convert_index_mask(decimal_mask,N)

[SIMU,N_samples] = size(decimal_mask);
binary_mask = zeros(SIMU,N_samples,N);
for n=1:N
    [row,col,pse] = find(decimal_mask == n);
    ind_aux = sub2ind([SIMU,N_samples,N],row,col,n*ones(length(row),1));
    binary_mask(ind_aux) = 1;
end

[target1 target2] = find(decimal_mask == 0);
if ~isempty(target1)
    ind_aux_2 = sub2ind([SIMU,N_samples,N],kron(ones(N,1),target1),kron(ones(N,1),target2),kron([1:N].',ones(length(target1),1)));
    binary_mask(ind_aux_2) = 1;
end
binary_mask_bin = logical(binary_mask);
