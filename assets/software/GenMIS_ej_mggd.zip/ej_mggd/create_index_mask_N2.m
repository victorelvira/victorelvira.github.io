function [index_matrix_weights] = create_index_mask_N2(index_matrix_sampling_reshaped,N,SIMU,N_samples)

blocks = N_samples/N;

binary_mask = zeros(SIMU*blocks,N,N);

for n=1:N
    [row,col,pse] = find(index_matrix_sampling_reshaped == n);
    ind_aux = sub2ind([SIMU*blocks,N,N],row,col,n*ones(length(row),1)); % Pero no solo al propio sino a los compa?eros de mixture % index_matrix_weights(:,1+(i-1)*N:i*N,)
    binary_mask(ind_aux) = 1;
end
binary_mask_sum = flipdim(cumsum(flipdim(binary_mask,2),2),2);

for i=1:N
index_matrix_weights(:,:,i) = reshape(binary_mask_sum(:,:,i).',blocks*N,SIMU).';
end

index_matrix_weights = index_matrix_weights > 0;
