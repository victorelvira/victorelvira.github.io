function [index_matrix_weights,mixt_weights] = create_index_mask_R2(index_matrix_sampling,N)

[SIMU,N_samples] = size(index_matrix_sampling);
mixt_weights = -ones(SIMU,N_samples,N);
binary_mask_madIS = zeros(SIMU,N_samples,N);
blocks = N_samples/N;
for n=1:N
    [row,col,pse] = find(index_matrix_sampling == n);
    row = row(:);
    col = col(:);
    pse = pse(:);

    ind_aux = sub2ind([SIMU,N_samples,N],row,col,n*ones(length(row),1)); 
    binary_mask_madIS(ind_aux) = 1;
end


for i=1:blocks
    mixt_weights(:,1+(i-1)*N:i*N,:) = repmat(sum(binary_mask_madIS(:,1+(i-1)*N:i*N,:),2),[1 N 1]);
end

index_matrix_weights = mixt_weights > 0;