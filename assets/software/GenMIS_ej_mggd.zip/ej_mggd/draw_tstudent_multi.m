function samples_matrix =  draw_tstudent_multi(index_matrix,mu_matrix,sig_matrix,nu_vector)

dim = size(mu_matrix,2);

index_matrix_vec_aux = index_matrix.';
index_matrix_vec = index_matrix_vec_aux(:);

samples_matrix = mu_matrix(index_matrix_vec,:) + sqrt(sig_matrix(index_matrix_vec,:)).*trnd(repmat(nu_vector(index_matrix_vec),1,dim),size(index_matrix_vec,1),dim);
 