clear all
clear all
close all
clc
tic
 
%% - Simulation Params
SIMU=2^5;
blocks_vector = 2^5;
blocks = blocks_vector(1);
dim_vector = [2 3 4 5 6 7 8 9 10];
%% - Target
for i=1:length(dim_vector)
    clearex r1 r2 r3 n1 n2 n3 i dim_vector SIMU blocks_vector blocks
    %- Generalized Gaussian
    tipo_target = 'ggNdim_3modes';
    target_params.dim = dim_vector(i);
    target_params.mu(1,:)= -3*ones(1,target_params.dim);
    target_params.mu(2,:)= 1*ones(1,target_params.dim);
    target_params.mu(3,:)= 5*ones(1,target_params.dim);
    target_params.rho = [1.1 1.8 2.2].';
 
    %- Prop t-student randomly-placed
    N = 500;
    dim_prop = target_params.dim;
    prop_params.mu = 12*(rand(N,dim_prop)-0.5);
    sig_prop = 5;
    prop_params.sig = sig_prop*repmat(eye(dim_prop),[1 1 N]);
    prop_params.type = 't';
    nu = 2.5;
    prop_params.nu = nu*ones(N,1);
      
     target_Z = 1;
    
    [target_mean target_modes] = compute_mean(tipo_target,target_params);
    
    filename = ['temp3_' num2str(randint(1,1,1000000))];
    
    
    %% R1
    [EstM_r1 EstM_r1_norm Zest_r1 ESS_r1] = R1_multi(prop_params,SIMU,blocks,tipo_target,target_params);
    %% N1
    [EstM_n1 EstM_n1_norm Zest_n1 ESS_n1] = N1_multi(prop_params,SIMU,blocks,tipo_target,target_params);
    %% R2
    [EstM_r2 EstM_r2_norm Zest_r2 ESS_r2] = R2_multi(prop_params,SIMU,blocks,tipo_target,target_params);
    %% N2
    [EstM_n2 EstM_n2_norm Zest_n2 ESS_n2] = N2_multi(prop_params,SIMU,blocks,tipo_target,target_params);
    %% R3
    [EstM_r3 EstM_r3_norm Zest_r3 ESS_r3] = R3_multi(prop_params,SIMU,blocks,tipo_target,target_params);
    %% N3
    [EstM_n3 EstM_n3_norm Zest_n3 ESS_n3] = N3_multi(prop_params,SIMU,blocks,tipo_target,target_params);
    
    r1.var_EstM(i) = mean(var(EstM_r1),2);
    n1.var_EstM(i) = mean(var(EstM_n1),2);
    r2.var_EstM(i) = mean(var(EstM_r2),2);
    n2.var_EstM(i) = mean(var(EstM_n2),2);
    r3.var_EstM(i) = mean(var(EstM_r3),2);
    n3.var_EstM(i) = mean(var(EstM_n3),2);
    
    
    r1.mse_EstM(i) = mean(mean((EstM_r1 - repmat(target_mean,SIMU,1)).^2),2);
    n1.mse_EstM(i) = mean(mean((EstM_n1 - repmat(target_mean,SIMU,1)).^2),2);
    r2.mse_EstM(i) = mean(mean((EstM_r2 - repmat(target_mean,SIMU,1)).^2),2);
    n2.mse_EstM(i) = mean(mean((EstM_n2 - repmat(target_mean,SIMU,1)).^2),2);
    r3.mse_EstM(i) = mean(mean((EstM_r3 - repmat(target_mean,SIMU,1)).^2),2);
    n3.mse_EstM(i) = mean(mean((EstM_n3 - repmat(target_mean,SIMU,1)).^2),2);
    
    r1.mse_EstM_norm(i) = mean(mean((EstM_r1_norm - repmat(target_mean,SIMU,1)).^2),2);
    n1.mse_EstM_norm(i) = mean(mean((EstM_n1_norm - repmat(target_mean,SIMU,1)).^2),2);
    r2.mse_EstM_norm(i) = mean(mean((EstM_r2_norm - repmat(target_mean,SIMU,1)).^2),2);
    n2.mse_EstM_norm(i) = mean(mean((EstM_n2_norm - repmat(target_mean,SIMU,1)).^2),2);
    r3.mse_EstM_norm(i) = mean(mean((EstM_r3_norm - repmat(target_mean,SIMU,1)).^2),2);
    n3.mse_EstM_norm(i) = mean(mean((EstM_n3_norm - repmat(target_mean,SIMU,1)).^2),2);
    
    r1.mse_Zest(i) = mean((Zest_r1 - repmat(target_Z,SIMU,1)).^2);
    n1.mse_Zest(i) = mean((Zest_n1 - repmat(target_Z,SIMU,1)).^2);
    r2.mse_Zest(i) = mean((Zest_r2 - repmat(target_Z,SIMU,1)).^2);
    n2.mse_Zest(i) = mean((Zest_n2 - repmat(target_Z,SIMU,1)).^2);
    r3.mse_Zest(i) = mean((Zest_r3 - repmat(target_Z,SIMU,1)).^2);
    n3.mse_Zest(i) = mean((Zest_n3 - repmat(target_Z,SIMU,1)).^2);
    
    
    r1.Zest_mean(i) = mean(Zest_r1);
    n1.Zest_mean(i) = mean(Zest_n1);
    r2.Zest_mean(i) = mean(Zest_r2);
    n2.Zest_mean(i) = mean(Zest_n2);
    r3.Zest_mean(i) = mean(Zest_r3);
    n3.Zest_mean(i) = mean(Zest_n3);
    
    r1.ESS(i) = ESS_r1/(blocks*N);
    r2.ESS(i) = ESS_r2/(blocks*N);
    r3.ESS(i) = ESS_r3/(blocks*N);
    n1.ESS(i) = ESS_n1/(blocks*N);
    n2.ESS(i) = ESS_n2/(blocks*N);
    n3.ESS(i) = ESS_n3/(blocks*N);

end
toc

%% Painting



blocks_vector_big = 2.^[0:12];

line_width = 2;
marker_size = 15;
fin = length(r1.mse_EstM_norm);

fig2 = figure(2);
semilogy(dim_vector,r1.mse_EstM,'yx-','LineWidth',line_width,'MarkerSize',marker_size);hold on
semilogy(dim_vector,n1.mse_EstM,'rs-','LineWidth',line_width,'MarkerSize',marker_size)
semilogy(dim_vector,r2.mse_EstM,'md-','LineWidth',line_width,'MarkerSize',marker_size)
semilogy(dim_vector,n2.mse_EstM,'co-','LineWidth',line_width,'MarkerSize',marker_size)
semilogy(dim_vector,r3.mse_EstM,'g*-','LineWidth',line_width,'MarkerSize',marker_size)
semilogy(dim_vector,n3.mse_EstM,'bv-','LineWidth',line_width,'MarkerSize',marker_size)
title('unnormalized estimator of target mean')
legend('R1','N1','R2','N2','R3','N3')
xlabel('M')
ylabel('MSE')

set(findall(fig2,'-property','FontSize'),'FontSize',20)

hold off
grid on


fig3 = figure(3);
semilogy(dim_vector,r1.mse_EstM_norm,'yx-','LineWidth',line_width,'MarkerSize',marker_size);hold on
semilogy(dim_vector,n1.mse_EstM_norm,'rs-','LineWidth',line_width,'MarkerSize',marker_size)
semilogy(dim_vector,r2.mse_EstM_norm,'md-','LineWidth',line_width,'MarkerSize',marker_size)
semilogy(dim_vector,n2.mse_EstM_norm,'co-','LineWidth',line_width,'MarkerSize',marker_size)
semilogy(dim_vector,r3.mse_EstM_norm,'g*-','LineWidth',line_width,'MarkerSize',marker_size)
semilogy(dim_vector,n3.mse_EstM_norm,'bv-','LineWidth',line_width,'MarkerSize',marker_size)

legend('R1','N1','R2','N2','R3','N3')
xlabel('M')
ylabel('MSE')

title('self-normalized estimator of target mean')

set(findall(fig3,'-property','FontSize'),'FontSize',20)
hold off
grid on

fig4 = figure(4);
semilogy(dim_vector,r1.mse_Zest,'yx-','LineWidth',line_width,'MarkerSize',marker_size);hold on
semilogy(dim_vector,n1.mse_Zest,'rs-','LineWidth',line_width,'MarkerSize',marker_size)
semilogy(dim_vector,r2.mse_Zest,'md-','LineWidth',line_width,'MarkerSize',marker_size)
semilogy(dim_vector,n2.mse_Zest,'co-','LineWidth',line_width,'MarkerSize',marker_size)
semilogy(dim_vector,r3.mse_Zest,'g*-','LineWidth',line_width,'MarkerSize',marker_size)
semilogy(dim_vector,n3.mse_Zest,'bv-','LineWidth',line_width,'MarkerSize',marker_size)

legend('R1','N1','R2','N2','R3','N3')
xlabel('M')
ylabel('MSE')

title('estimator of Z')

set(findall(fig4,'-property','FontSize'),'FontSize',20)
hold off
grid on
