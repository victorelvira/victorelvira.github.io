function target_eval_matrix = evaluate_target_multidim(x_matrix,tipo_target,target_params,SIMU,N_samples)
if strcmp(tipo_target,'gm1')
    
      mu_target = target_params.mu;
    sig_target = target_params.sig;
    
    index_matrix = zeros(size(x_matrix)); % Zeros means evaluating the whole mixture
    target_eval_vector = evaluate_gaussian_uni(x_matrix,index_matrix,mu_target,sig_target);
    
    if size(target_eval_vector,2) == 1
        target_eval_matrix = reshape(target_eval_vector,N_samples,SIMU).';
    else
        error('It should be a vertical vector')
    end
    
elseif strcmp(tipo_target,'gm2')
    
    mu_matrix = target_params.mu;
    sig_matrix = target_params.sig;
    N = size(mu_matrix,1);
    ind_mat = ones(SIMU,N_samples,N)==1; 
    target_eval_matrix = evaluate_gaussian_multi_bin(x_matrix,ind_mat,mu_matrix,sig_matrix);
    
elseif strcmp(tipo_target,'gm2_5modes')
    N = 5;
    mu_matrix(1,:)=[-10 -10];
    mu_matrix(2,:)=[0 16];
    mu_matrix(3,:)=[13 8];
    mu_matrix(4,:)=[-9 7];
    mu_matrix(5,:)=[14 -14];
    
    sig_matrix = [2 0.6; 0.6 1];
    sig_matrix(:,:,2) = [2 -0.4;-0.4 2];
    sig_matrix(:,:,3) = [2 0.8;0.8 2];
    sig_matrix(:,:,4) = [3 0; 0 0.5];
    sig_matrix(:,:,5) = [2 -0.1;-0.1 2];
    
    ind_mat = ones(SIMU,N_samples,N)==1;
    target_eval_matrix = evaluate_gaussian_multi_bin(x_matrix,ind_mat,mu_matrix,sig_matrix);
elseif strcmp(tipo_target,'ts2_5modes')
    N = 5;

    mu_matrix = target_params.mu;
    sig_matrix = target_params.sig;
    nu_vector = target_params.nu_vector;
    sig_prop_matrix_iso = extrac_diag_iso(sig_matrix);
    
    ind_mat = ones(SIMU,N_samples,N)==1;
    
    target_eval_matrix = evaluate_tstudent_multi_bin_iso(x_matrix,ind_mat,mu_matrix,sig_prop_matrix_iso,nu_vector);
elseif strcmp(tipo_target,'ts2_3modes')
    N = 3;

    mu_matrix = target_params.mu;
    sig_matrix = target_params.sig;
    nu_vector = target_params.nu_vector;
    sig_prop_matrix_iso = extrac_diag_iso(sig_matrix);
    
    ind_mat = ones(SIMU,N_samples,N)==1;    
    target_eval_matrix = evaluate_tstudent_multi_bin_iso(x_matrix,ind_mat,mu_matrix,sig_prop_matrix_iso,nu_vector);

elseif strcmp(tipo_target,'ggNdim_3modes')
    n_modes = size(target_params.mu,1);
    Tot_samples = size(x_matrix,1);
    target_eval_vector = zeros(size(x_matrix,1),1);
    for n=1:n_modes
        rho = target_params.rho(n);
        aux_n = 1/(2*gamma(1+1/rho)).*exp(-abs(x_matrix-repmat(target_params.mu(n,:),Tot_samples,1)).^rho);
        target_eval_vector = target_eval_vector + prod(aux_n,2);
    end
    target_eval_vector = target_eval_vector/n_modes;
    target_eval_matrix = reshape(target_eval_vector,N_samples,SIMU).'; 

end