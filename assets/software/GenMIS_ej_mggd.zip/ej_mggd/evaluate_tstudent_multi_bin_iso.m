function prop_eval_matrix =  evaluate_tstudent_multi_bin_iso(x_matrix,ind_mat,mu_matrix,sig_matrix_iso,nu_vector,weight_mat)

if nargin<6
    weight_mat = ind_mat+0;
end

[SIMU,N_samples,N] = size(ind_mat);
dim = size(mu_matrix,2);
prop_eval_matrix_aux = zeros(SIMU,N_samples,N);
for n=1:N
    ind_mat_n_aux = ind_mat(:,:,n).'; 
    ind_mat_n = ind_mat_n_aux(:); 
    x_matrix_mixand_n = x_matrix(ind_mat_n,:);
    prop_eval_vec_n = ones(size(x_matrix_mixand_n,1),1);
    for d = 1:dim

        prop_eval_vec_n = prop_eval_vec_n.*tpdf((x_matrix_mixand_n(:,d)-mu_matrix(n,d))/sqrt(sig_matrix_iso(n,d)),nu_vector(n))/sqrt(sig_matrix_iso(n,d));
    end
    prop_eval_matrix_n_aux1 = zeros(N_samples,SIMU);
    prop_eval_matrix_n_aux1(ind_mat_n_aux) = prop_eval_vec_n; 
    prop_eval_matrix_n_aux2 = prop_eval_matrix_n_aux1.';
    prop_eval_matrix_aux(:,:,n) = prop_eval_matrix_n_aux2;
end

N_mixands_matrix = sum(ind_mat,3);
prop_eval_matrix = sum(prop_eval_matrix_aux.*weight_mat,3)./N_mixands_matrix; 


 