function sig_2d = extrac_diag_iso(sig_3d)

N = size(sig_3d,3);
for n=1:N
    sig_2d(n,:) = diag(sig_3d(:,:,n));
end