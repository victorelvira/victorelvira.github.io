function [Psi,Phi,Delta] = EM_parameters_TSP(x,z_mean_smooth,P_smooth,G_smooth,z_mean_smooth0,P_smooth0,G_smooth0)

K = size(x,2);
Nz = size(z_mean_smooth,1);

%initialize
Psi = zeros(Nz,Nz);
Phi   = zeros(Nz,Nz);
Delta     = zeros(Nz,Nz);

for k = 2:K
    Psi = Psi + (P_smooth(:,:,k) + z_mean_smooth(:,k)*z_mean_smooth(:,k)');
    Phi = Phi + (P_smooth(:,:,k-1) + z_mean_smooth(:,k-1)*z_mean_smooth(:,k-1)');
    Delta   = Delta + (P_smooth(:,:,k)*G_smooth(:,:,k-1)' + z_mean_smooth(:,k)*z_mean_smooth(:,k-1)');
end
%for k = 1
Psi = Psi + (P_smooth(:,:,1) + z_mean_smooth(:,1)*z_mean_smooth(:,1)');
Phi   = Phi + (P_smooth0 + z_mean_smooth0*z_mean_smooth0');
Delta     = Delta + (P_smooth(:,:,1)*G_smooth0' + z_mean_smooth(:,1)*z_mean_smooth0');

