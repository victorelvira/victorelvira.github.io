function [Q,invQ] = GLASSO_update_PROX(Psi,Phi,Delta,K,A,reg,Xx0,teta,majinit)

 




reg2 = reg.reg2;%(1);
gamma2 = reg.gamma2;
 
teta_K_2 = teta*K/2;

%WARNING: change of variable !
Psi = Psi./K;
Phi = Phi./K;
Delta = Delta./K; 
D = Psi - A*Delta' - Delta*A' + A*Phi*A';
D = (D + D')/2; 

max_iter = 10000;
precision = 1e-3; 
display = 0;

% Xx0 = inv(Qinit);

% Here, we compute the prox of {teta * [K/2*trace(P*D) - K/2 * log(det(2*pi*P)) + gamma2 * reg(P) ] } at Xx0
%which is equivalent to the prox of {teta * [K/2*trace(P*D) - K/2 * log(det(P)) + gamma2 * reg(P) ] } at Xx0

if(display==1)
    disp(['start inner loop on Q with majinit = ',num2str(majinit)]);
    %pause
end
%invQ = minimizer of f(Q) = trace(D*invQ) - logdet(invQ) 
%+ gamma2*||invQ||_1 (this term appears in case 1)

switch reg2
    case 0 %no penalization
        %prox of {teta * [K/2*trace(P*D) - K/2 * log(det(P)) ] } at Xx0
        
        %disp(teta*(K/2*trace(Xx0*D) - K/2 * log(det(Xx0))))
        
        stepsize = teta_K_2;
        point    = Xx0 - teta_K_2.*D;
        invQ = prox_Logdet(point,stepsize);
        
        %disp(teta*(K/2*trace(invQ*D) - K/2 * log(det(invQ))) + 1/2*norm(invQ - Xx0,'fro')^2)
        
        Q = inv(invQ);
    case 2 %l2 penalization 
        %prox of {teta * [K/2*trace(P*D) - K/2 * log(det(P))  + gamma/2 ||P||^2_F] } at Xx0
        stepsize = teta_K_2/(teta*gamma2 + 1);
        point    = (Xx0 - teta_K_2.*D)./(teta*gamma2 + 1);
        invQ = prox_Logdet(point,stepsize);        
        Q = inv(invQ);
    case 1 %l1 penalization, run Dikstra-like algorithm
        
        
%         Z = Xx0;  
        Xx = Xx0;
        V = zeros(size(Xx));
        W = zeros(size(Xx));
        
        %stepdik = 1.5;
        
        for k = 1:max_iter
            % we compute prox_{f}(Xx + V)
            temp = Xx + V;
            Z = sign(temp) .* max(0, abs(temp) - gamma2*teta); 
            V = Xx + V - Z;
            
            % we compute prox_g(Z + W)
            temp = Z + W;
            Xx = prox_Logdettrace(temp,D,teta_K_2);
            W = Z + W - Xx;
                        
            obj(k) = - K/2*log(det(Z*2*pi)) + K/2*trace(Z*D) + gamma2*sum(abs(Z(:)));

            if(display==1)
                disp(['(inner loop) update Q: iter = ',num2str(k),'-> obj = ',num2str(obj(k))]);

            end
            
            if(k>1)
                if(abs(obj(k)-obj(k-1))<=precision && obj(k) <= majinit)
                    if(display==1)
                        disp(['Subroutine for Q stops at iter = ',num2str(k)]);
                    end
                    break;
                end
            end
            
        end
        if(k==max_iter)
            disp('Q: maximum iteration number reached')
        end
        
        if(display==1)
            figure(100)
            hold off
            plot(obj)
            pause
        end
        invQ = Z;
        Q = inv(invQ);
end



