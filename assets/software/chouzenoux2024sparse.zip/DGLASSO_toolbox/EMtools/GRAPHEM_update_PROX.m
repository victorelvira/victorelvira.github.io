function D1 = GRAPHEM_update_PROX(Psi,Phi,Delta,K,invQ,reg,D10,teta,Maj_D1)

% Here, we compute the prox of {teta * [1/2*trace(invQ*(Psi - Delta*A -
% A*Delta' + A * Phi * A')) + gamma1 * reg(A) + iota_S(A) ] } at D10


reg1 = reg.reg1;%(1);
gamma1 = reg.gamma1;
gammat1 = gamma1*teta;

ItDR = 20000;
display = 0;
precision = 1e-3;



switch reg1
    case 0 %no penalization
% Here, we compute the prox of {teta * [1/2*trace(invQ*(Psi - Delta*A -
% A*Delta' + A * Phi * A'))] } at D10
        D1 = prox_ML_D1_TSP(Delta,Phi,invQ,teta,D10);
    case 2 %l2 penalization    
% Here, we compute the prox of {teta * [1/2*trace(invQ*(Psi - Delta*A -
% A*Delta' + A * Phi * A')) + gamma1/2 ||A||_2^F ] } at D10
        D1 = prox_ML_D1_TSP(Delta,Phi,invQ,teta/(gammat1+1),D10./(gammat1+1));
    case 1 %l1 penalization
        %run Dikstra algorithm
        
        X = D10;
        V = zeros(size(X));
        W = zeros(size(X));
        
        %gam = 1.5;
        for i = 1:ItDR
            % we compute prox_{f}(X + V)
            Z = prox_L1(1,gammat1,X + V);
            V = X + V - Z;
            
            % we compute prox_g(Z + W)
            X = prox_ML_D1_TSP(Delta,Phi,invQ,teta,Z + W);
            W = Z + W - X;
            
            
            obj(i) = ComputeMaj_TSP(Z,invQ,Psi,Phi,Delta,K) ...
                + Compute_Prior_D1(Z,reg);
            
            if(display==1)
                disp(['i = ',num2str(i),'; obj = ',num2str(obj(i))]);
            end
                
            if(i>1)
                if(abs(obj(i)-obj(i-1))<=precision && obj(i) < Maj_D1)
                    if(display==1)
                        disp(['Subroutine for A stops at i = ',num2str(i)]);
                    end
                    break;
                end
            end
        end
        D1 = Z;
        
        if(i==ItDR)
            disp('A: maximum iteration number reached')
        end
        
        if(display==1)
            figure(100)
            hold off
            plot(obj)
            pause
        end
        
 
end



