function [xk_mean_new,Pk_new,vk,Sk,Pk_minus,Kk,nuk] = Kalman_update(y_k,xk_mean_past,Pk_past,A,H,R,Q)

xk_minus = A*xk_mean_past;
Pk_minus = A*Pk_past*A' + Q;

nuk = H*xk_minus;
vk = y_k - nuk;
Sk = H*Pk_minus*H' + R;
try
    Sk_inv = pinv(Sk);
    Kk = Pk_minus*H'*Sk_inv;
catch
    keyboard;
end
xk_mean_new = xk_minus + Kk*vk;
Pk_new = Pk_minus - Kk*Sk*Kk';

