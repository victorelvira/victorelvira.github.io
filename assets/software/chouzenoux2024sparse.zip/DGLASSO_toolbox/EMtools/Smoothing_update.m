function [zk_smooth_new,Pk_smooth_new,Gk] = Smoothing_update(zk_kal,Pk_kal,zk_smooth_past,Pk_smooth_past,A,H,R,Q)

zk_minus = A*zk_kal;
Pk_minus = A*Pk_kal*A' + Q;

Gk = Pk_kal*A'*pinv(Pk_minus);
zk_smooth_new = zk_kal + Gk*(zk_smooth_past - zk_minus);
Pk_smooth_new = Pk_kal + Gk*(Pk_smooth_past - Pk_minus)*Gk';
 
%