function Maj = ComputeMaj_TSP(A,invQ,Psi,Phi,Delta,K)
 
Maj = - K/2 * log(det(2*pi*invQ)) + 1/2 * trace(invQ*(Psi - A*Delta' - Delta*A' + A*Phi*A'));







