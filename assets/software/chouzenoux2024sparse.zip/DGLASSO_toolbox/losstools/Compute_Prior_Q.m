function Reg2 = Compute_Prior_Q(invQ,reg)

reg2 = reg.reg2;%(1);
gamma2 = reg.gamma2;

switch reg2
    case 0
        Reg2 = 0;
    case 1
        Reg2 = gamma2.*sum(abs(invQ(:)));
    case 2
        Reg2 = gamma2/2 * norm(invQ,'fro')^2;
end

