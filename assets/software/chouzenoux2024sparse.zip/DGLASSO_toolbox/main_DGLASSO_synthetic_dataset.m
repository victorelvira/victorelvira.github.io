close all
clear all
clc

addpath datasets
addpath EMtools
addpath losstools
addpath matrixtools
addpath proxtools
addpath simulators

%% generate synthetic data
Nreal = 5; % Number of independent runs 
K  = 1000; % length of time series
flag_plot = 0;

load datasets/D1_datasetA_s27.mat;
D1 = A;%A <-> D1
% load ground truth matrix A
%-----------------
Nx = size(D1,1); % number of nodes
Nz = Nx;
D2 = eye(Nz);   % for simplicity and identifiability purposes %H <-> D2

load datasets/Q_dataset02.mat % load ground truth matrix Q
P = inv(Q);

%---
figure
subplot(311)
imagesc(D1); colorbar; colormap hot; axis image
title('true A')

subplot(312)
imagesc(Q); colorbar; colormap hot; axis image
title('true Q')

subplot(313)
imagesc(P); colorbar; colormap hot; axis image
title('true P')

p = 1;%markov order
sigma_R = 0.1; % observation noise std
R = sigma_R^2*eye(Nx);
sigma_P = 0.0001; % prior state std
P0 = sigma_P^2*eye(Nz);
z0 = ones(Nx,1);

rng('default');

gamma1 = 8;
gamma2 = 1;



thetaA = 1; %thetaA is the prox stepsize wrt A
thetaQ = 1; %thetaQ is the prox stepsize wrt Q


%% Create a validation set (for cross val)
[xval,zval] = GenerateSynthetic_order_p_matrices(K,D1,D2,p,z0,P0,Q,R);

%% run KF - RTS on validation set using ground truth matrices
z_mean_kalman_gt = zeros(Nz,K);
P_kalman_gt = zeros(Nz,Nz,K);
yk_kalman_gt = zeros(Nx,K);
Sk_kalman_gt = zeros(Nx,Nx,K);
nuk_kalman_gt = zeros(Nx,K);

[z_mean_kalman_gt(:,1),P_kalman_gt(:,:,1),yk_kalman_gt(:,1),Sk_kalman_gt(:,:,1),~,~,nuk_kalman_gt(:,1)] = Kalman_update(xval(:,1),z0,P0,D1,D2,R,Q);
for k = 2:K
    [z_mean_kalman_gt(:,k),P_kalman_gt(:,:,k),yk_kalman_gt(:,k),Sk_kalman_gt(:,:,k),~,~,nuk_kalman_gt(:,k)] = Kalman_update(xval(:,k),z_mean_kalman_gt(:,k-1),P_kalman_gt(:,:,k-1),D1,D2,R,Q);
end

PhiK_ml_gt = Compute_PhiK(0,Sk_kalman_gt,yk_kalman_gt);
%cNMSE on val set
z_mean_smooth_gt= zeros(Nz,K);
P_smooth_gt = zeros(Nz,Nz,K);
G_smooth_gt = zeros(Nz,Nz,K);
z_mean_smooth_gt(:,K) = z_mean_kalman_gt(:,K);
P_smooth_gt(:,:,K) = P_kalman_gt(:,:,K);
for k = fliplr(1:K-1)
    [z_mean_smooth_gt(:,k),P_smooth_gt(:,:,k),G_smooth_gt(:,:,k)] = ...
        Smoothing_update(z_mean_kalman_gt(:,k),P_kalman_gt(:,:,k),z_mean_smooth_gt(:,k+1),P_smooth_gt(:,:,k+1),D1,D2,R,Q);
end
[z_mean_smooth0_gt,P_smooth0_gt,G_smooth0_gt] = Smoothing_update(z0,P0,z_mean_smooth_gt(:,1),P_smooth_gt(:,:,1),D1,D2,R,Q);


%%
for real = 1:Nreal
    
    disp(['---- REALIZATION ',num2str(real),' ----']);
    
    %% Synthetic data generation
    
    x = GenerateSynthetic_order_p_matrices(K,D1,D2,p,z0,P0,Q,R);
    saveX(:,:,real) = x;
    
    
    
    
    reg.reg1 = 1; %l1 norm
    reg.gamma1 = gamma1;
    
    reg.reg2 = 1; %l1 norm
    reg.gamma2 = gamma2;
    
    
    %% Inference (DGLASSO algorithm)
    disp('-- DGLASSO --')
    
    Err_D1 = [];
    Nit_em = 50; %number of iterations maximum for EM loop
    prec = 1e-3; %precision for EM loop
    
    %initialization of GRAPHEM-GLASSO
    
    disp(['Update A: Regularization on A: norm L1 with gamma1 = ',num2str(gamma1)]);
    D1_em = prox_stable(CreateAdjacencyAR1(Nz,0.1),0.99);
    D1_em_save = [];
    
    %matrix Q
    disp(['Update Q: Regularization on Q: norm L1 with gamma2 = ',num2str(gamma2)]);
    Q_em = 0.1*eye(Nz);
    invQ_em = inv(Q_em);
    
    for i = 1:Nit_em % EM iterations
        %disp(['EM iteration ',num2str(i)]);
        
        %1/ Kalman filter
        z_mean_kalman_em = zeros(Nz,K);
        P_kalman_em = zeros(Nz,Nz,K);
        yk_kalman_em = zeros(Nx,K);
        Sk_kalman_em = zeros(Nx,Nx,K);
        [z_mean_kalman_em(:,1),P_kalman_em(:,:,1),yk_kalman_em(:,1),Sk_kalman_em(:,:,1)] = Kalman_update(x(:,1),z0,P0,D1_em,D2,R,Q_em);
        for k = 2:K
            [z_mean_kalman_em(:,k),P_kalman_em(:,:,k),yk_kalman_em(:,k),Sk_kalman_em(:,:,k)] = Kalman_update(x(:,k),z_mean_kalman_em(:,k-1),P_kalman_em(:,:,k-1),D1_em,D2,R,Q_em);
        end
        
        %compute loss function (ML for now, no prior)
        PhiK_ml = Compute_PhiK(0,Sk_kalman_em,yk_kalman_em);
        
        %compute penalty function  before update
        Reg1_before = Compute_Prior_D1(D1_em,reg);
        Reg2_before = Compute_Prior_Q(invQ_em,reg);
        Reg_before = Reg1_before + Reg2_before;
        
        MLsave(i) = PhiK_ml;
        Regsave(i) = Reg_before;
        PhiK(i) = PhiK_ml + Reg_before; %update loss function
        
        
        %2/ Kalman smoother
        z_mean_smooth_em = zeros(Nz,K);
        P_smooth_em = zeros(Nz,Nz,K);
        G_smooth_em = zeros(Nz,Nz,K);
        z_mean_smooth_em(:,K) = z_mean_kalman_em(:,K);
        P_smooth_em(:,:,K) = P_kalman_em(:,:,K);
        for k = fliplr(1:K-1)
            [z_mean_smooth_em(:,k),P_smooth_em(:,:,k),G_smooth_em(:,:,k)] = ...
                Smoothing_update(z_mean_kalman_em(:,k),P_kalman_em(:,:,k),z_mean_smooth_em(:,k+1),P_smooth_em(:,:,k+1),D1_em,D2,R,Q_em);
        end
        [z_mean_smooth0_em,P_smooth0_em,G_smooth0_em] = Smoothing_update(z0,P0,z_mean_smooth_em(:,1),P_smooth_em(:,:,1),D1_em,D2,R,Q_em);
        
        % compute EM parameters as defined in TSP paper
        [Psi,Phi,Delta] = EM_parameters_TSP(x,z_mean_smooth_em,P_smooth_em,G_smooth_em,z_mean_smooth0_em,P_smooth0_em,G_smooth0_em);
        
        %compute majorant function for ML term before update (we ignore
        %terms not depending of A nor Q)
        
        Maj_before_ml = ComputeMaj_TSP(D1_em,invQ_em,Psi,Phi,Delta,K);
        Maj_before(i) = Maj_before_ml + Reg_before;     %add prior term (= majorant for MAP term)
        
        %3/ EM Update
        %initialization for the prox alternating step
        D1_temp = D1_em;
        Q_temp = Q_em;
        invQ_temp = invQ_em;
        
        
        MajA_temp = Maj_before_ml + Reg1_before ;
        
        estimA_mm =  (mod(i,2));
        estimQ_mm =  abs((mod(i,2)-1));
        
        
        %UPDATE MATRIX A
        if(estimA_mm==1)
            % Here, we compute (iteratively) the prox of {thetaA * [1/2*trace(invQ_temp*(Psi - Delta*A -
            % A*Delta' + A * Phi * A')) + gamma1 * reg(A) + iota_S(A) ] } at D1_temp
            %we assume that we initialize the prox update in the same point
            %D1_temp where we compute the prox (easier!)
            
            D1_temp = GRAPHEM_update_PROX(Psi,Phi,Delta,K,invQ_temp,reg,D1_temp,thetaA,MajA_temp);
            Maj_interm_ml = ComputeMaj_TSP(D1_temp,invQ_temp,Psi,Phi,Delta,K);
            %                 %compute penalty function after update
            Reg1_interm = Compute_Prior_D1(D1_temp,reg);
            MajA_new = Maj_interm_ml + Reg1_interm;
            
            Reg_interm = Reg1_interm + Reg2_before;
            Maj_interm = Maj_interm_ml + Reg_interm;      %add complete prior term (= majorant for complete MAP term)
        else
            %                 D1_temp = D1_em;
            Maj_interm_ml = Maj_before_ml;
            Maj_interm = Maj_before(i);
            MajA_new = MajA_temp;
        end
        
        if(MajA_new> MajA_temp)
            disp(['WARNING (update A): Majorant increases at iteration ',num2str(i)]);
            disp(MajA_new - MajA_temp)
            %keyboard;
        end
        MajA_temp = MajA_new;
        MajQ_temp = ComputeMaj_TSP(D1_temp,invQ_temp,Psi,Phi,Delta,K) + Compute_Prior_Q(invQ_temp,reg) ;
        %------------------------------
        
        %UPDATE MATRIX Q
        if(estimQ_mm==1)
            
            %we assume that we initialize the prox update in the same point
            %Q_temp where we compute the prox (easier!)
            [Q_temp,invQ_temp] = GLASSO_update_PROX(Psi,Phi,Delta,K,D1_temp,reg,invQ_temp,thetaQ,MajQ_temp);
            MajQ_new = ComputeMaj_TSP(D1_temp,invQ_temp,Psi,Phi,Delta,K) + Compute_Prior_Q(invQ_temp,reg) ;
        else
            MajQ_new = MajQ_temp;
        end
        
        if(MajQ_new> MajQ_temp)
            disp(['WARNING (update Q): Majorant increases at iteration ',num2str(i)]);
            disp(MajQ_new - MajQ_temp)
            %keyboard;
        end
        
        %the prox loop is over. We store the updates for A and Q
        Q_em_ = Q_temp;
        invQ_em_= invQ_temp;
        D1_em_ = D1_temp;
        
        %compute majorant function for ML term after update of Q (to check decrease)
        Maj_after(i) = ComputeMaj_TSP(D1_em_,invQ_em_,Psi,Phi,Delta,K);
        %add penalty function after update
        Reg1_after = Compute_Prior_D1(D1_em_,reg);
        Reg2_after = Compute_Prior_Q(invQ_em_,reg);
        Reg_after = Reg1_after + Reg2_after;
        Maj_after(i) = Maj_after(i) + Reg_after;
        %------------------------------
        
        
        D1_em = D1_em_; % D1 estimate updated (which will be used in the next iteration for Kalman)
        Q_em = Q_em_;
        invQ_em = invQ_em_;
        
        D1_em_save(:,:,i) = D1_em; % keep track of the sequence
        Q_em_save(:,:,i) = Q_em; % keep track of the sequence
        
        Err_D1(i) = norm(D1-D1_em,'fro')/norm(D1,'fro');  %
        Err_Q(i) = norm(Q-Q_em,'fro')/norm(Q,'fro');  %
        Err_P(i) = norm(P-invQ_em,'fro')/norm(P,'fro');
        Err_Q_2(i) = norm(Q-Q_em)/norm(Q);
        Err_P_2(i) = norm(P-invQ_em)/norm(P);
        
        %stopping criterion
        if(i>1)
            if(estimA_mm==1)
                if(norm(D1_em_save(:,:,i-1)-D1_em_save(:,:,i),'fro')/norm(D1_em_save(:,:,i-1),'fro')< prec)
                    breakA = 1;
                    %disp(['stop condition on A holds at iter ',num2str(i)]);
                else
                    breakA = 0;
                end
            else

                breakA = 0;

            end
            
            if(estimQ_mm==1)
                if(norm(Q_em_save(:,:,i-1)-Q_em_save(:,:,i),'fro')/norm(Q_em_save(:,:,i-1),'fro')< prec)
                    breakQ = 1;
                    %disp(['stop condition on Q holds at iter ',num2str(i)]);
                else
                    breakQ = 0;
                end
            else

                breakQ = 0;

            end
            if( (breakQ && breakA) ==1)
                disp(['EM converged after iteration ',num2str(i)]);
                break;
            end
        end
        
    end
    
    %compute metrics
    
    %marginal likelihood on train set
    MLsave_end(real) = PhiK_ml;
    
    %marginal likelihood on validation set
    z_mean_kalman_val = zeros(Nz,K);
    P_kalman_val = zeros(Nz,Nz,K);
    yk_kalman_val = zeros(Nx,K);
    Sk_kalman_val = zeros(Nx,Nx,K);
    nuk_kalman_val = zeros(Nx,K);
    [z_mean_kalman_val(:,1),P_kalman_val(:,:,1),yk_kalman_val(:,1),Sk_kalman_val(:,:,1),~,~,nuk_kalman_val(:,1)] = Kalman_update(xval(:,1),z0,P0,D1_em,D2,R,Q_em);
    for k = 2:K
        [z_mean_kalman_val(:,k),P_kalman_val(:,:,k),yk_kalman_val(:,k),Sk_kalman_val(:,:,k),~,~,nuk_kalman_val(:,k)] = Kalman_update(xval(:,k),z_mean_kalman_val(:,k-1),P_kalman_val(:,:,k-1),D1_em,D2,R,Q_em);
    end
    cNMSE(real) = sum(sum((z_mean_kalman_val - z_mean_kalman_gt).^2,1),2)/sum(sum(z_mean_kalman_gt.^2,1),2);
    
    cNMSE_(real) = sum(sum((nuk_kalman_val - nuk_kalman_gt).^2,1),2)/sum(sum(nuk_kalman_gt.^2,1),2);
    
    
    
    disp(['cNMSE - observation -  on val = ',num2str(cNMSE_(real))]);
    disp(['cNMSE - state - KF -  on val = ',num2str(cNMSE(real))]);
    PhiK_ml_val = Compute_PhiK(0,Sk_kalman_val,yk_kalman_val);
    MLsave_end_val(real) = PhiK_ml_val;
    
    %cNMSE on validation set
    z_mean_smooth_val= zeros(Nz,K);
    P_smooth_val = zeros(Nz,Nz,K);
    G_smooth_val = zeros(Nz,Nz,K);
    z_mean_smooth_val(:,K) = z_mean_kalman_val(:,K);
    P_smooth_val(:,:,K) = P_kalman_val(:,:,K);
    for k = fliplr(1:K-1)
        [z_mean_smooth_val(:,k),P_smooth_val(:,:,k),G_smooth_val(:,:,k)] = ...
            Smoothing_update(z_mean_kalman_val(:,k),P_kalman_val(:,:,k),z_mean_smooth_val(:,k+1),P_smooth_val(:,:,k+1),D1_em,D2,R,Q_em);
    end
    [z_mean_smooth0_val,P_smooth0_val,G_smooth0_val] = Smoothing_update(z0,P0,z_mean_smooth_val(:,1),P_smooth_val(:,:,1),D1_em,D2,R,Q_em);
    
    cNMSE2(real) = sum(sum((z_mean_smooth_val - z_mean_smooth_gt).^2,1),2)/sum(sum(z_mean_smooth_gt.^2,1),2);
    disp(['cNMSE - state - RTS -  on val = ',num2str(cNMSE2(real))]);
    
    % validation in terms of true positive/false positive/error in A, etc.
    disp('--')
    
    
    D1_em_save = squeeze(D1_em_save);
    disp(['A: RMSE = ',num2str(Err_D1(end))]);
    
    threshold = 1e-10;
    D1_binary = abs(D1)>=threshold;
    D1_em_binary = abs(D1_em)>=threshold;
    
    AUC_A = fastAUC(D1_binary(:),abs(D1_em(:)));
    
    [TP, FP, TN, FN] = calError(D1_binary, D1_em_binary);
    if(flag_plot==1)
        figure(30)
        subplot(121)
        G = digraph(D1);
        LWidths = 5*abs(G.Edges.Weight)/max(G.Edges.Weight);
        hfig = plot(G,'LineWidth',LWidths);
        title('true A')
        subplot(122)
        G_em = digraph(D1_em);
        LWidths_em = 5*abs(G_em.Edges.Weight)/max(G.Edges.Weight);
        plot(G_em,'XData',hfig.XData,'YData',hfig.YData,'LineWidth',LWidths_em);
        set(gca,'xtick',[])
        set(gca,'ytick',[])
        title('estimated A')
    end
    precision(real) = TP/(TP + FP);
    recall(real) = TP/(TP + FN);
    specificity(real) = TN/(TN + FP);
    accuracy(real) = (TP + TN)/(TP+TN+FP+FN);
    RMSE(real) = Err_D1(end);
    F1score(real) = 2*TP /(2*TP + FP + FN);
    auc(real) = AUC_A;

    disp(['A: accuracy = ',num2str(accuracy(real)),'; precision = ',num2str(precision(real)),'; recall = ',num2str(recall(real)),'; specificity = ',num2str(specificity(real))]);
    
    
    
    RMSEQ(real) = Err_Q(end);
    disp(['Q: RMSE = ',num2str(RMSEQ(real))]);
    RMSEP(real) = Err_P(end);
    disp(['P: RMSE = ',num2str(RMSEP(real))]);
    threshold = 1e-10;
    P_binary = abs(P)>=threshold;
    P_em_binary = abs(invQ_em)>=threshold;
    
    AUC_P = fastAUC(P_binary(:),abs(invQ_em(:)));
    
    [TP_, FP_, TN_, FN_] = calError(P_binary,P_em_binary);
    
    if(flag_plot==1)
        figure(31)
        subplot(121)
        G = digraph(P);
        LWidths = 5*abs(G.Edges.Weight)/max(G.Edges.Weight);
        hfig = plot(G,'LineWidth',LWidths);
        title('true P')
        subplot(122)
        G_em = digraph(invQ_em);
        LWidths_em = 5*abs(G_em.Edges.Weight)/max(G.Edges.Weight);
        plot(G_em,'XData',hfig.XData,'YData',hfig.YData,'LineWidth',LWidths_em);
        set(gca,'xtick',[])
        set(gca,'ytick',[])
        title('estimated P')
    end
    
    precision_(real) = TP_/(TP_ + FP_);
    recall_(real) = TP_/(TP_ + FN_);
    specificity_(real) = TN_/(TN_ + FP_);
    accuracy_(real) = (TP_ + TN_)/(TP_+TN_+FP_+FN_);
    F1score_(real) = 2*TP_ /(2*TP_ + FP_ + FN_);
    auc_(real) = AUC_P;

    disp(['P: accuracy = ',num2str(accuracy_(real)),'; precision = ',num2str(precision_(real)),'; recall = ',num2str(recall_(real)),'; specificity = ',num2str(specificity_(real))]);
    
    
    
    
    
    
end

disp('--- end of realizations loop ---')
disp('-> cNMSE on validation set <-')
disp(['average cNMSE - state KF - on val = ',num2str(mean(cNMSE))])
disp(['average cNMSE - state RTS - on val = ',num2str(mean(cNMSE2))])
disp(['average cNMSE - observation KF - on val = ',num2str(mean(cNMSE_))])

disp('-> ML on validation set <-')
disp(['average marginal likelihood - on val (GT) = ',num2str(mean(PhiK_ml_gt))])
disp(['average marginal likelihood - on val = ',num2str(mean(MLsave_end_val))])
%
disp('-> averaged scores for A <-')
disp(['average RMSE = ',num2str(mean(RMSE))])
disp(['average auc = ',num2str(mean(auc))])
disp(['average accuracy = ',num2str(mean(accuracy))])
disp(['average precision = ',num2str(mean(precision))])
disp(['average recall = ',num2str(mean(recall))])
disp(['average specificity = ',num2str(mean(specificity))])
disp(['average F1 score = ',num2str(mean(F1score))])

disp('-> averaged scores for Q / P <-')
disp(['average RMSE (P) = ',num2str(mean(RMSEP))])
disp(['average RMSE (Q) = ',num2str(mean(RMSEQ))])

disp(['average auc = ',num2str(mean(auc_))])
disp(['average accuracy (P) = ',num2str(mean(accuracy_))])
disp(['average precision (P) = ',num2str(mean(precision_))])
disp(['average recall (P) = ',num2str(mean(recall_))])
disp(['average specificity (P) = ',num2str(mean(specificity_))])
disp(['average F1 score (P) = ',num2str(mean(F1score_))])





%%
if(flag_plot==1)
    
    figure
    subplot(321)
    imagesc(D1); colorbar; colormap hot; axis image
    title('true A')
    subplot(322)
    imagesc(D1_em); colorbar; colormap hot; axis image
    title('estimated A')
    
    subplot(323)
    imagesc(Q); colorbar; colormap hot; axis image
    title('true Q')
    subplot(324)
    imagesc(Q_em); colorbar; colormap hot; axis image
    title('estimated Q')
    
    
    subplot(325)
    imagesc(P); colorbar; colormap hot; axis image
    title('true P')
    subplot(326)
    imagesc(invQ_em); colorbar; colormap hot; axis image
    title('estimated P')
    
    figure(3)
    subplot(121)
    semilogy(Err_D1(2:2:end),'linewidth',1.5)
    title('Error on A')
    xlabel('DGLASSO iterations')
    subplot(122)
    semilogy(Err_Q(2:2:end),'linewidth',1.5)
    title('Error on Q')
    xlabel('DGLASSO iterations')

    figure(4)
    plot(0:length(PhiK)-1,PhiK,'linewidth',1.5)
    %plot(PhiK(2:2:end),'linewidth',1.5)
    ylabel('Loss')
    xlabel('Iterations')
    set(gca,'fontsize',16)
    grid on
end


 
 
