function P = prox_Logdettrace(X,Y,gamma)
%P = prox_{gamma*(-logdet(.) + trace(Y*.)}(X)

T = X - gamma.*Y;


% spectral decomposition
[v,s] = eig(T);

g=0.5*(s+sqrt((s).^2+4*gamma)) ;
% spectral reconstruction
P = v*diag(diag(g))*v';


