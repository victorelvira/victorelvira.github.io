function D1prox = prox_ML_D1_TSP(Delta,Phi,invQ,gamma,D1)


% Here, we compute the prox of {gamma * [1/2*trace(invQ*(Psi - Delta*A -
% A*Delta' + A * Phi * A'))] } at D1

invPhi = inv(Phi);
D1prox = lyap(gamma*invQ,invPhi,-gamma*invQ*Delta*invPhi - D1*invPhi);

%D1prox = (gamma*Delta + D1)*inv(gamma*Phi + eye(size(Phi,1))); 