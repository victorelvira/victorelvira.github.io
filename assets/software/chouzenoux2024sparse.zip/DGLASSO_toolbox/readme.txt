DGLASSO

*******************************************************
* author: Emilie Chouzenoux   and Victor Elvira			      *
* institution: Inria Saclay and University of Edinburg 		      *
* date: Thursday 6th July 2023      	              	              *
* License CeCILL-B                                    		      *
*******************************************************


*****************************************************
* RECOMMENDATIONS:                                 		      *
* This toolbox is designed to work with             		      *
* Matlab R2019 and forthcoming versions 			      *
*****************************************************

------------------------------------------------------------------------------------
DESCRIPTION:
This toolbox implements a Bayesian inference method, called DGLASSO (Dynamical Graphical Lasso), to estimate two graphs representing static and dynamical behaviors, respectively, in the hidden state of a linear Gaussian state-space model describing a multivariate time series. The estimation of the graphs is performed under sparsity prior, jointly with the construction of the filtering/smoothing distribution for the time series. The method relies on an original optimization algorithm, implementing a block alternating proximal algorithm with efficient majorization-minimization steps. The convergence of the algorithm is guaranteed.
 
This toolbox consists of 6 subfolders:
1) dataset: contains all the synthetic datasets from [1, Section 5.1].
2) EMtools: contains functions for building EM algorithm updates
3) losstools: contains functions for evaluating the likelihood and prior loss
4) matrixtools: contains functions for block sparsity models and for score computations
5) proxtools: contains functions for evaluating useful proximity operators
6) simulators: contains functions to generate time series and initialization
------------------------------------------------------------------------------------
SPECIFICATIONS for using DGLASSO:
A demo file is provided :
* main_DGLASSO_synthetic.m runs one typical example of [1, Section 5.1]. 


------------------------------------------------------------------------------------
RELATED PUBLICATION:
[1] E. Chouzenoux and V. Elvira. Sparse Graphical Linear Dynamical Systems. Preprint. 2023
---------