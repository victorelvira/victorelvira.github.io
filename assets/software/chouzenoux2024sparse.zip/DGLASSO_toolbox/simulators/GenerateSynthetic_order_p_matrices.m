function [y,x] = GenerateSynthetic_order_p_matrices(K,A,H,p,x0,P0,Q,R)

[Ny,Nx] = size(H);

x = zeros(Nx,K);
y = zeros(Ny,K);

Q12 = sqrtm(Q);
P12 = sqrtm(P0);
R12 = sqrtm(R);

%A is of size Nx x Nx x p

%initialization of the state
for pp=1:p
    x(1:Nx,pp) = x0 + P12*randn(Nx,1);
    y = H*x(1:Nx,pp) + R12*randn(Ny,1);
end

for k = p+1:K
    deterministic_state = zeros(Nx,1);
     for pp = 1:p
         deterministic_state = deterministic_state + A(:,:,pp)*x(:,k-pp);
     end    
    x(:,k) =  deterministic_state + Q12*randn(Nx,1);
    y(:,k) = H*x(:,k) + R12*randn(Ny,1);  
end
 