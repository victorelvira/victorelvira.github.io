function [mean_est,Z_est,x_IS,W,output]=Lower_Layer_MIS(mu,mu_sp,N,T,M,sig_lower_layer,type_MIS,tp)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%   IMPLEMENTATION OF MULTIPLE IMPORTANCE SAMPLING SCHEMES   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%   WITHIN LAYERED ADAPTIVE IMPORTANCE SAMPLING (LAIS)   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%      (see references below)                     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% V. Elvira, L. Martino, D. Luengo, M. F. Bugallo,
%%% "Generalized Multiple Importance Sampling", 
%%% https://arxiv.org/abs/1511.03095
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% L. Martino, V. Elvira, D. Luengo, J. Corander,
%%% "Layered Adaptive Importance Sampling", Statistics and Computing, 2016.
%%% doi:10.1007/s11222-016-9642-5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Total_prop=N*T;
disp_flag = 0;

switch type_MIS
    case 1
        aux='Deterministic - Standard IS (N1)';
        NumDen=1;
        NumProp=1;
    case 2
        aux='Deterministic - Full spatial-temporal DM';
        NumDen=1;
        NumProp=N*T;
    case 3
        aux='Deterministic - Spatial DM (N3)';
        NumDen=T;
        NumProp=N;
    case 4
        aux='Multinomial - a posteriori standard IS (R1)';
        NumDen=1;
        NumProp=1;
    case 5
        aux='Multinomial - standard DM (R3)';
        NumDen=T;
        NumProp=N;
    case 6
        aux='Multinomial - a posteriori DM (R2)';
        NumDen=T;
        NumProp=N;
    case 7
        aux='Multinomial without replacement - a priori DM (R2)';
        NumDen=T;
        NumProp=N;
end

mu_true = tp.mu_true;
DIM = tp.dim;
logf=@(x) target(x.',tp);

switch  type_MIS % MIS schemes
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 1 % Deterministic - Standard IS (N1)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        for j=1:Total_prop
            SIGMA_p=sig_lower_layer(j)*eye(DIM);
            x_IS(:,M*(j-1)+1:M*j)=mvnrnd(mu(:,j),SIGMA_p,M)';
            P(M*(j-1)+1:M*j)=mvnpdf(x_IS(:,M*(j-1)+1:M*j)',mu(:,j)',SIGMA_p);
            logNUM(M*(j-1)+1:M*j)=logf(x_IS(:,M*(j-1)+1:M*j)')';
        end
        logDEN=log(P);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 2 % Deterministic - Full spatial-temporal DM
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        for j=1:Total_prop
            SIGMA_p=sig_lower_layer(j)*eye(DIM);
            x_IS(:,M*(j-1)+1:M*j)=mvnrnd(mu(:,j),SIGMA_p,M)';
            logNUM(M*(j-1)+1:M*j)=logf(x_IS(:,M*(j-1)+1:M*j)')';
            if mod(j,10)==0 && disp_flag
                disp(['computing IS denominators...',num2str(min([fix(j*100/Total_prop) 100])) '%'])
            end
            for k=1:Total_prop
                P(k,M*(j-1)+1:M*j)=mvnpdf(x_IS(:,M*(j-1)+1:M*j)',mu(:,k)',SIGMA_p);
                %%% P size N*T \times N*T*M
                %%% row => evaluation one proposal pdf at all the samples
                %%% (row index=> denote one proposal pdf)
                %%% (column index=> denote one sample)                
            end
        end
        P=mean(P);
        logDEN=log(P);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 3 % Deterministic - Spatial DM (N3)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        count=1;
        t=1;
        for j=1:Total_prop
            SIGMA_p=sig_lower_layer(j)*eye(DIM);
            x_IS(:,M*(j-1)+1:M*j)=mvnrnd(mu(:,j),SIGMA_p,M)';
            x_ISsp{t}(:,M*(count-1)+1:M*count)=x_IS(:,M*(j-1)+1:M*j);
            count=count+1;
            if mod(j,N)==0
                t=t+1;
                count=1;
            end
            logNUM(M*(j-1)+1:M*j)=logf(x_IS(:,M*(j-1)+1:M*j)')';
            
        end
        for t=1:T % Iteration
            if mod(t,10)==0 && disp_flag
                disp(['computing IS denominators...',num2str(min([fix(t*100/T) 100])) '%'])
            end
            %             keyboard
            for n=1:N % Proposal ( % x_ISsp{t}' is MN x dim )
                Maux(n,:)=mvnpdf(x_ISsp{t}',mu_sp{t}(n,:),SIGMA_p); % Maux: N x MN
            end
            %             keyboard
            a(t,:)=log(mean(Maux)); % a(t,:): 1 x MN
        end
        logDEN = reshape(a',1,N*T*M);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 4 % Multinomial - a posteriori standard IS (R1)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        mu_aux = [];
        for tt=1:T % multinomial sampling in mu, but in mu_sp all the mixtures are preserved
            mu_aux = [mu_aux mu_sp{tt}(randi(N,1,N),:).'];
        end
        mu = mu_aux;
        
        for j=1:Total_prop
            SIGMA_p=sig_lower_layer(j)*eye(DIM);
            x_IS(:,M*(j-1)+1:M*j)=mvnrnd(mu(:,j),SIGMA_p,M)';
            P(M*(j-1)+1:M*j)=mvnpdf(x_IS(:,M*(j-1)+1:M*j)',mu(:,j)',SIGMA_p);
            logNUM(M*(j-1)+1:M*j)=logf(x_IS(:,M*(j-1)+1:M*j)')';
        end
        logDEN=log(P);
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 5 % Multinomial - standard DM (R3)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        count=1;
        t=1;
        
        mu_aux = [];
        for tt=1:T % multinomial sampling in mu, but in mu_sp all the mixtures are preserved
            mu_aux = [mu_aux mu_sp{tt}(randi(N,1,N),:).'];
        end
        mu = mu_aux;
        
        for j=1:Total_prop
            SIGMA_p=sig_lower_layer(j)*eye(DIM);
            x_IS(:,M*(j-1)+1:M*j)=mvnrnd(mu(:,j),SIGMA_p,M)'; % Sampling
            x_ISsp{t}(:,M*(count-1)+1:M*count)=x_IS(:,M*(j-1)+1:M*j); % Muestras e
            count=count+1;
            if mod(j,N)==0
                t=t+1;
                count=1;
            end
            logNUM(M*(j-1)+1:M*j)=logf(x_IS(:,M*(j-1)+1:M*j)')';
            
        end
        
        for t=1:T % iteration
            if mod(t,10)==0 && disp_flag
                disp(['computing IS denominators...',num2str(min([fix(t*100/T) 100])) '%'])
            end
            for n=1:N % proposal ( % x_ISsp{t}' is MN x dim )
                Maux(n,:)=mvnpdf(x_ISsp{t}',mu_sp{t}(n,:),SIGMA_p); % Maux: N x MN
            end
            a(t,:)=log(mean(Maux)); % a(t,:): 1 x MN
        end
        logDEN = reshape(a',1,N*T*M);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 6 % Multinomial - a posteriori DM (R2)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        count=1;
        t=1;
        
        mu_aux = [];
        for tt=1:T % multinomial sampling in mu, and also in mu_sp all
            aux_indexes = randi(N,1,N);
            mu_aux = [mu_aux mu_sp{tt}(aux_indexes,:).'];
            mu_sp{tt} = mu_sp{tt}(aux_indexes,:);
        end
        mu = mu_aux;
        
        for j=1:Total_prop
            SIGMA_p=sig_lower_layer(j)*eye(DIM);
            x_IS(:,M*(j-1)+1:M*j)=mvnrnd(mu(:,j),SIGMA_p,M)'; % sampling
            x_ISsp{t}(:,M*(count-1)+1:M*count)=x_IS(:,M*(j-1)+1:M*j); 
            count=count+1;
            if mod(j,N)==0
                t=t+1;
                count=1;
            end
            logNUM(M*(j-1)+1:M*j)=logf(x_IS(:,M*(j-1)+1:M*j)')';
            
        end
        
        for t=1:T % iteration
            if mod(t,10)==0 && disp_flag
                disp(['computing IS denominators...',num2str(min([fix(t*100/T) 100])) '%'])
            end
            for n=1:N % proposal ( % x_ISsp{t}' is MN x dim )
                Maux(n,:)=mvnpdf(x_ISsp{t}',mu_sp{t}(n,:),SIGMA_p); % Maux: N x MN
            end
            a(t,:)=log(mean(Maux)); % a(t,:): 1 x MN
        end
        logDEN = reshape(a',1,N*T*M);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    case 7 % Multinomial without replacement - a priori DM (R2) 
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        mu_aux = [];
        for tt=1:T % permutation of mu. All proposals will be used but in a different order.
            aux_indexes = randperm(N);
            mu_aux = [mu_aux mu_sp{tt}(aux_indexes,:).'];
            mu_sp{tt} = mu_sp{tt}(aux_indexes,:);
        end
        mu = mu_aux;
        
        
        count=1;
        t=1;
        for j=1:Total_prop
            SIGMA_p=sig_lower_layer(j)*eye(DIM);
            x_IS(:,M*(j-1)+1:M*j)=mvnrnd(mu(:,j),SIGMA_p,M)';
            x_ISsp{t}(:,M*(count-1)+1:M*count)=x_IS(:,M*(j-1)+1:M*j);
            count=count+1;
            if mod(j,N)==0
                t=t+1;
                count=1;
            end
            logNUM(M*(j-1)+1:M*j)=logf(x_IS(:,M*(j-1)+1:M*j)')';
        end
        
        for t=1:T % iteration
            if mod(t,10)==0 && disp_flag
                disp(['computing IS denominators...',num2str(min([fix(t*100/T) 100])) '%'])
            end
            Maux = [];
            for n=1:N % proposal ( % x_ISsp{t}' is MN x dim )
                Maux(n,:)=mvnpdf(x_ISsp{t}',mu_sp{t}(n,:),SIGMA_p); % Maux: N x MN
            end
            for mm=1:N*M
                a(t,mm)=log(mean(Maux(1:ceil(mm/M),mm))); % a(t,:): 1 x MN
            end
            
        end
        logDEN = reshape(a',1,N*T*M);
end % MIS schemes

%- Weighting 
W=exp(logNUM-logDEN);

%- Estimators
Z_est=mean(W); % Normalizing constant estimation
Wn=W./(Total_prop*M*Z_est);
mean_est=sum(repmat(Wn,DIM,1).*x_IS,2);
SE_mean=(mu_true.' - mean_est).^2;
output.Z_est = Z_est;
output.mean_est = mean_est;
output.SE_mean = SE_mean;

%% Disp and plot

if disp_flag == 1
    disp('-----------------------------------------------------------------------------------------')
    disp('****-****-****-****-****-****-****-****')
    disp('****       LOWER-LAYER            *****')
    disp('****-****-****-****-****-****-****-****')
    disp('-----------------------------------------------------------------------------------------')
    disp(['Number of proposal pdfs used in MIS = ' num2str(Total_prop) ' '])
    disp(['Number of samples per proposal= ' num2str(M)])
    disp(['Total number of used samples = ' num2str(Total_prop*M)])
    disp(' ')
    disp(['Type IS-Denominator= ' aux])
    disp(['Number of different denominators = ' num2str(NumDen)])
    disp(['Number of proposal pdfs in each denominator = ' num2str(NumProp)])
    disp('-----------------------------------------------------------------------------------------')
    disp(' ')
    disp('RESULTS')
    disp(' ')
    disp(['Marginal likelihood- estimated value = ', num2str(Z_est)])
    disp(' ')
    disp(['Expected Value of the posterior/target pdf - True Values = ',num2str(mu_true')])
    disp(['Expected Value of the  posterior/target pdf-Estimated Values= ',num2str(mean_est')])
    disp(['Square Error in the estimation of the Expected Value = ', num2str(SE_mean)])
end

plot_flag = 0;
if (tp.type==1 || tp.type==2 || tp.type==3) && plot_flag
    if tp.type==1
        hgload('contourGauss5modes.fig');
    end
    hold on
    plot(x_IS(1,:),x_IS(2,:),'g.','MarkerEdgeColor','g','MarkerFaceColor','g','MarkerSize',1)
    plot(mu(1,:),mu(2,:),'rs','MarkerEdgeColor','k','MarkerFaceColor','r','MarkerSize',5)
    axis([-22 22 -25 25])
end
