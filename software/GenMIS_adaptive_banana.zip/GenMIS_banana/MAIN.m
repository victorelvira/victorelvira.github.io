%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%   IMPLEMENTATION OF MULTIPLE IMPORTANCE SAMPLING SCHEMES   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%   WITHIN LAYERED ADAPTIVE IMPORTANCE SAMPLING (LAIS)   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%      (see references below)                     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% V. Elvira, L. Martino, D. Luengo, M. F. Bugallo,
%%% "Generalized Multiple Importance Sampling", 
%%% https://arxiv.org/abs/1511.03095
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% L. Martino, V. Elvira, D. Luengo, J. Corander,
%%% "Layered Adaptive Importance Sampling", Statistics and Computing, 2016.
%%% doi:10.1007/s11222-016-9642-5
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
close all
clc

%- Target parameters (tp)
tp.type = 7; % Banana-shaped target
tp.dim = 15; % Dimension of the state-space
tp.mu_true = zeros(1,tp.dim); % True mean of the target
tp.dims2show = [1 2]; % Dimensions to show in a 2-dimensional plot

%- Algorithm parameters
N = 200; % Number of proposals per iteration (N>=1)
T = 1000; % Number of iterations (T>=1)
M = 1; % Number of samples per proposal per iteration (M>=1)
sig_upper=0.2; %%% std of the proposal pdfs of upper layer
sig_lower_layer=0.5*ones(1,N*T);

%- Simulation parameters
RUNS = 2;
schemes = [1 3:7]; % set of MIS schemes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% schemes:
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% 1 - Deterministic - Standard IS (N1)
%%%% 2 - Deterministic - Full spatial-temporal DM
%%%% 3 - Deterministic - Spatial DM (N3)
%%%% 4 - Multinomial - a posteriori standard IS (R1)
%%%% 5 - Multinomial - standard DM (R3)
%%%% 6 - Multinomial - a posteriori DM (R2)
%%%% 7 - Multinomial without replacement - a priori DM (R2) 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
scheme_strings{1} = 'N1';scheme_strings{2} = 'DM';scheme_strings{3} = 'N3';scheme_strings{4} = 'R1';scheme_strings{5} = 'R3';scheme_strings{6} = 'R2';scheme_strings{7} = 'N2';
%% Simulation
% Upper Level: MCMC for chosing the means of the lower level proposals
% (same simulation in all methods)
for nn=1:RUNS
[mu_tot,mu_sp,~] = Upper_Layer_ParMH(N,T,sig_upper,tp); % mu_tot: dim x TN. % mu_tot: struct of size T of dim x T vectors.
plot_banana(tp);hold on;plot(mu_tot(tp.dims2show(1),:),mu_tot(tp.dims2show(2),:),'r.');hold off

disp('-----------------------------------------------------------------------------------------')
disp('****-****-****-****-****-****-****-****')
disp('****       LOWER-LAYER            *****')
disp('****-****-****-****-****-****-****-****')
disp('-----------------------------------------------------------------------------------------')

% Lower level: MIS
    for i=schemes
        disp(['Run: ' num2str(nn) '. MIS scheme: ' num2str(i)  ])
        type_MIS = i;
        [~,~,~,~,output] = Lower_Layer_MIS(mu_tot,mu_sp,N,T,M,sig_lower_layer,type_MIS,tp);
        SE_mean_all{i}(:,nn) = output.SE_mean;
        mean_all{i}(:,nn) = output.mean_est;
    end
end 

%% Results processing

for i=schemes
    disp('---------------------------------------')
    disp(['MSE in mean (' scheme_strings{i} '): ' num2str(mean(mean(SE_mean_all{i})))])
end