function vec_loglik = plot_banana(tp)
dim = tp.dim;
vec_loglik = [];
grid_vector = [-5:0.1:5];
dims2show = tp.dims2show;
for yy = grid_vector
    for xx = grid_vector
        point(dims2show(1)) = xx;
        point(dims2show(2)) = yy;
        [logtarget,~,~,~,~] = target(point.',tp);
        vec_loglik = [vec_loglik logtarget];
    end
end



%%
matrix_loglik = reshape(vec_loglik,length(grid_vector),length(grid_vector));
pcolor(grid_vector,grid_vector,exp(matrix_loglik.'))
xlabel('x1')
ylabel('x2')
