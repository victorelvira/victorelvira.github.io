function [logtarget,target,DIM,mu_true,Marglike_true] = target(x,tp)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%   IMPLEMENTATION OF MULTIPLE IMPORTANCE SAMPLING SCHEMES   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%   WITHIN LAYERED ADAPTIVE IMPORTANCE SAMPLING (LAIS)   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%      (see references below)                     %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% V. Elvira, L. Martino, D. Luengo, M. F. Bugallo,
%%% "Generalized Multiple Importance Sampling",
%%% https://arxiv.org/abs/1511.03095
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% L. Martino, V. Elvira, D. Luengo, J. Corander,
%%% "Layered Adaptive Importance Sampling", Statistics and Computing, 2016.
% %%% doi:10.1007/s11222-016-9642-5
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

switch tp.type
    case 7 % banana
        dim = tp.dim;
        if dim == 2
            b=3;
            sig = 1;
            logtarget= -x(1,:).^2/(2*sig^2) - ( x(2,:) + b*(x(1,:).^2 - sig.^2)).^2/(2*sig^2);
            f=exp(logtarget);
            f1=0;
            f2=0;
            f3=0;
            f4=0;
            f5=0;     
            target = f';
            DIM = 2;
            mu_true = [0 0];
            Marglike_true = NaN; 
            
        elseif dim>2
            b=3;
            sig = 1;
            logtarget= -x(1,:).^2/(2*sig^2) - ( x(2,:) + b*(x(1,:).^2 - sig.^2)).^2/(2*sig^2);
            logtarget = logtarget -sum(x(3:end,:).^2/(2*sig^2),1); % all other dimensions are Gaussian
            f=exp(logtarget);
            f1=0;
            f2=0;
            f3=0;
            f4=0;
            f5=0;
            
            target = f';
            DIM = 2;
            mu_true = zeros(DIM,1);
            Marglike_true = 1; 
        end 
end

