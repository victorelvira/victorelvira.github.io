
clear all
close all
clc
help ej_gm_LAIS

typeTar=1;
%%% typeTar: type of the  target distribution
%%% typeTar=1,2,3 =>DIM=2
%%% typeTar=4 =>DIM=4
%%% typeTar=5 =>DIM=10
%%% Build your inference problem, changing target.m
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% upper layer: parallel MH chains  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
N=100; %%% N>=1
T=200; %%% T>=1 
M=1; %%% M>=1 %%% samples per proposal pdfs in the lower layer

sig_prop=5; %%std of the proposal pdfs of upper layer
[mu_tot,mu_sp,~]=Upper_Layer_ParMH(N,T,sig_prop,typeTar); % mu_tot: dim x TN. % mu_tot: struct of size T of dim x T vectors.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% lower layer: MIS schemes         %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
sig_lower_layer=2*ones(1,N*T);
%%%%%%%%%%
%%% SUGGESTION: USE typeDEN=3 
% typeDEN=7; %%%% type of the MIS scheme
%%%% 1 - Standard IS (N1)
%%%% 2 - Full spatial-temporal DM
%%%% 3 - Spatial DM (N3)
%%%% 4 - Multinomial Standard IS (R1)
%%%% 5 - Multinomial Spatial DM (R3)
%%%% 6 - Multinomial Spatial-Consequent DM (R2)
%%%% 7 - Multinomial without resampling - Spatial DM (N2) [FALTA]
scheme_strings{1} = 'N1';scheme_strings{2} = 'DM';scheme_strings{3} = 'N3';scheme_strings{4} = 'R1';scheme_strings{5} = 'R3';scheme_strings{6} = 'R2';scheme_strings{7} = 'N2';
SIMU = 5;
for nn=1:SIMU
    for i=[1 3:7]
        disp(['Den. ' num2str(i) '. Simu.' num2str(nn) ])
        typeDEN = i;
        [x_est,MarginalLike,x_IS,W,output]=Lower_Layer_IS(mu_tot,mu_sp,N,T,M,sig_lower_layer,typeDEN,typeTar);
        SE_Z_all{i}(nn) = output.SE_Z;
        SE_mean_all{i}(:,nn) = output.SE_mean;
    end
    if mod(nn,20) == 0
        save temp
    end
end

    save(['temp_T_' num2str(T)])

%% Process results
clc
for i=1:7
    disp('---------------------------------------')
    disp(['MSE in Z (' scheme_strings{i} '):    ' num2str(mean(SE_Z_all{i}))])
    disp(['MSE in mean (' scheme_strings{i} '): ' num2str(mean(mean(SE_mean_all{i})))]) 
end

