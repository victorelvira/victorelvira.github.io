clear all
close all
clc


%%%% number of parallel chains
N=20; %%% N>2
%%%% total number of evaluations of the target
Et=1.01*10^4;
%%%%  number of vertical and horizontal steps per epoch
Tv=5;
Th=1; %%% suggested for a robust application Th=N%%% 
%%%%% number of epochs will be 
M=fix(Et/(N*Tv+Th));


sig_prop_V=5; %%std of the vertical proposal pdfs
sig_prop_H=20; %%%% std of the horizontal proposal; initial value; it is adapted on-line
%%%%%%%%%%
%%%%%%%%%%
%%%%%%%%%%
[x_tot]=OMCMC_SMH(N,Tv,Th,M,sig_prop_V,sig_prop_H);