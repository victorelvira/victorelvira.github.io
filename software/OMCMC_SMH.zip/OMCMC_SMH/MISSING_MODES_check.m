function [countsampleINMode]=MISSING_MODES_check(x)
%%% auxiliaty file %%%
%%%% we could compute the rate of ``exchanges'' among modes %%%%%

     mu1=[-10 -10];
      SIGMA1 = [2 0.6; 0.6 1];
      mu2=[0 16];
      SIGMA2 = [2 -0.4;-0.4 2];
      mu3=[13 8];
      SIGMA3 = [2 0.8;0.8 2];
      mu4=[-9 7];
      SIGMA4 = [3 0; 0 0.5];
      mu5=[14 -14];
      SIGMA5 = [2 -0.1;-0.1 2];
      
    f(:,1)=mvnpdf(x,mu1,SIGMA1);
    f(:,2)=mvnpdf(x,mu2,SIGMA2);
    f(:,3)=mvnpdf(x,mu3,SIGMA3);
    f(:,4)=mvnpdf(x,mu4,SIGMA4);
     f(:,5)=mvnpdf(x,mu5,SIGMA5);
    
    aux=max(f');
   
    MODE=[0 0 0 0 0];
    countsampleINMode=[0 0 0 0 0];
    for j=1:length(x)
    MODE(j)=find(f(j,:)==aux(j));
    countsampleINMode(MODE(j))=countsampleINMode( MODE(j))+1;
    end
    
    