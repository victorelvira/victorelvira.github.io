function x_tot=OMCMC_SMH(N,Tv,Th,M,sigpropV,sigpropH)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% simplified version of O-MCMC-SMH %%%%%%%
% %% with multimodal bivariate target %%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % L. Martino, V. Elvira, D. Luengo, J. Corander, F. Louzada 
% % Orthogonal parallel MCMC methods for sampling and optimization,
% % arXiv:1507.08577, 2015
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % N= number of chain
% % M= number of Epochs
% % sigpropV = std of the proposal pdfs of the vertical chains
% % sigproph = initial std of the proposal pdf in SMH
% % x_tot= returned samples (states of the chains)


if N<2
    N=2;
end 

if M<1
    M=1;
end 

if Tv<1
    Tv=1;
end 
    


   disp('-----------------------------------------------------------------------------------------')
   disp('****-****-****-****-****-****-****-****')
   disp('****       OMCMC-SMH              *****')
   disp('****-****-****-****-****-****-****-****')
   disp('-----------------------------------------------------------------------------------------')
    disp(['Number of chains= ' num2str(N), ' '])
    disp(['Vertical steps in one epoch= ' num2str(Tv)]) 
    disp(['Horinzontal steps in one epoch  Th= ' num2str(Th)])
    disp(['Number of Epochs, M= ', num2str(M)])
   disp(['total number of evaluations, Et=(N*Tv+Th)*M=  ' num2str((N*Tv+Th)*M)])
   disp(['Training formed by these number of steps (fix(M/(0.7*Tv*N)); suggested) =  ' num2str(fix(M/(0.7*N*Tv)))])
   disp('-----------------------------------------------------------------------------------------')
  disp(['Total number of vertical steps = ' num2str(M*Tv)]) 
  disp(['Total number of horinzontal steps = ' num2str(M*Th)]) 
   disp('-----------------------------------------------------------------------------------------')
   
   
     
    
    



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% TARGET %%%%%%%%%%%%%%%%%%%%%
type=1; %%%% type of the  target distribution %%% change target.m
logf=@(x) target(x,type);
DIM=2; %%% problem dimension 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% parameters %%%%%%%%%%%%%%%%%%%%%
initialPoints=-4+8*rand(N,DIM);
x{1}=initialPoints;
SIGMA=sigpropV.^2*eye(DIM);
x_tot=[];
mupropH=0*ones(DIM,1);
sigpropHvect=sigpropH*ones(DIM,1);
 Training=fix(M/(0.7*Tv*N)); %%% possible suggestion
 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% aux code par. %%%%%%%%%%%%%%%%%%%%%
showPlots=1; %%% 0: nothing 1: show  
   counter=1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%% START %%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=2:M+1;
    
   if mod(i,100)==0
       disp([num2str(min([fix(i*100/M) 100])) '%'])
   end

 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%%%%%%%%%%% Propagation of the VERTICAL CHAINS %%%%%%%%%%%%%
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
  for j=1:Tv 
      
     counter=counter+1;
     x{counter}=mvnrnd(x{counter-1},SIGMA);
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    Vbef=logf(x{counter-1});
    Vnow=logf(x{counter});
    [d1,d2]=size(Vbef);
     if d1>d2
         Vbef=Vbef';
         Vnow=Vnow';
     end
    rho=exp(Vnow-Vbef);
    alpha=min([ones(1,N);rho]);
    %%% Test %%%
    u=rand(1,N);
    test=(u<=alpha);
    vec_aux=(x{counter}-x{counter-1}).*repmat(test',1,DIM);
    x{counter}=x{counter-1}+vec_aux;
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
      x_tot=[x_tot x{counter}'];
 
  end
  
  
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%%%%%%%%%%% SMH  %%%%%%%%%%%%%
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       
 
  %%%%%%% adaptation of parameters after training %%%%%
       if i>Training
           mupropH=mean(x_tot,2);
           %%%% partial adaptation of covariance matrix (in order to simplify the code) %%%%
           sigpropHvect=sqrt(var(x_tot')')+0.2;
       end
       
       
       if Th~=0
       x_now=SMH(mupropH,sigpropHvect,N,Th,x{counter}',logf);
         counter=counter+1;
          x{counter}=x_now';
        x_tot=[x_tot x{counter}'];
       end
  
  
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%% END of one EPOCH %%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       
       
end





if showPlots==1
% disp('Results')
% disp('Mean of all samples')
% mean(x_tot(1,:))
% mean(x_tot(2,:))
% disp('True values')
% mean([-10 0 13 -9 14])
% mean([-10 16 8 7 -14])

Countaux=MISSING_MODES_check(x_tot');
disp(' ')
disp('Check MISSING MODE: ')
disp(['distributed of the ', num2str((N*Tv+N*Th)*M), ' generated states in each of the 5 modes: '])
disp([num2str(Countaux)])



close all
 
   
  % figure 
  hgload('contourGauss5modes.fig');
  hold on
plot(x_tot(1,:),x_tot(2,:),'r--')
axis([-20 20 -20 20])

%%%% initial states %%%%
plot(x{1}(:,1),x{1}(:,2),'ks','MarkerEdgeColor','k','MarkerFaceColor','g','MarkerSize',10)

text(-6,-6,'Starting states','Fontsize',20)
text(-15,-15,'Mode-1','Fontsize',20)
text(-11,17,'Mode-2','Fontsize',20)
text(10,13,'Mode-3','Fontsize',20)
text(-18,10,'Mode-4','Fontsize',20)
text(3,-15,'Mode-5','Fontsize',20)

end