function xend=SMH(muprop,sigprop,N,Tchain,xpop,logf)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% SMH: Sample Metropolis-Hastings %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



cont=0;

M=length(sigprop);


for t=1:Tchain 
    
     ESO=logf(xpop');
     f=exp(ESO');
      
    P=evaluate_proposal(xpop,repmat(muprop,1,N),repmat(sigprop,1,N));
   
    win=P./f+10^(-300);
    win_n=win./sum(win); 
    pos=randsrc(1,1,[1:N;win_n]); 
 
    
    z=muprop+sigprop.*randn(M,1);
    ESO=logf(z');
    fz=exp(ESO);
  
    win(end+1)=evaluate_proposal(z,muprop,sigprop)./fz;
   
    a=sum(win(1:end-1))./(sum(win)-min(win));
    
    u=rand(1,1);
    if u<=a     
     xpop(:,pos)=z;     
    end
    
    
    
end

xend=xpop;
