function fp=evaluate_proposal(x,mu,sig)

K=1; %% to avoid numerical problems




value =K*exp(-0.5 * ((x - mu)./sig).^2) ./ (sqrt(2*pi) .* sig);
fp=prod(value);

